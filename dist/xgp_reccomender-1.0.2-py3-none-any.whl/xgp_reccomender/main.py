import xgp_reccomender


def main():
    """Main function"""
    my_xgp_reccomender = xgp_reccomender.XgpReccomender()
    my_xgp_reccomender.generate_html()


if __name__ == '__main__':
    main()
