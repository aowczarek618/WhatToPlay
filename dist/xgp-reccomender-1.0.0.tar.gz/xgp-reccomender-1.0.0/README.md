# xgp-reccomender
App searches for avaiable Xbox Game Pass games and helps to choose what to play next.
