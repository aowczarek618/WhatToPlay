# xgp-reccomender
App searches for avaiable Xbox Game Pass games and helps to choose what to play based on Metacritics and your ratings.

## Instalation
> pip3 install xgp-reccomender

## Usage
> python3 /path/to/script/main.py

Rating games is done via [rated_games](rated_games). 1 is for liked games and -1 is the opposite. You can type whatever integer you want, but I reccomend to stick with -1, 1 values.

## Output
The output of `main.py` script is [game_ranking.html](game_ranking.html). There is simple css file written for better visualizing.
